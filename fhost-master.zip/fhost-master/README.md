# fhost #
The viewer of static file on line
# Quick Guide #
## Install ##
```
npm install -g fhost
```
## Start Web Host ##
cd the folder that you want to view, then execute:
```
fhost run 
```
That will launch the web host, and the default port is 8080. You can change port by command:
```
fhost run -p [port whatever you want]
```
## Access ##
Enter address 'http://localhost:8080/' in your browser, you will see the file/folder list of the folder in which you execute fhost command.
